const web3Adapter = require('./utils/web3-adapter.js')
const config = require('../config.json')

async function commit(qAmount) {
  const validators = await web3Adapter.validators()

  try {
    const callData = validators.methods.commitCollateral().encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(validators._address, nonce, qAmount, callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Committed ${qAmount} Q as validator stake. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Validator stake commit failed: ${err}`)  
  }
}

async function enterShortList() {
  const validators = await web3Adapter.validators()
  try {
    const callData = validators.methods.enterShortList().encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const qAmount = '0'
    const txObject = await web3Adapter.buildTransaction(validators._address, nonce, qAmount, callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Entered validator short list. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Enter short list failed: ${err}`)  
  }
}

async function announceWithdrawal(qAmount) {
  const validators = await web3Adapter.validators()
  try {
    const rawAmount = web3Adapter.utils.toWei(qAmount)
    const callData = validators.methods.announceWithdrawal(rawAmount).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(validators._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Announced withdrawal of ${qAmount} Q. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Announce Withdrawal failed: ${err}`)  
  }
}

async function withdraw(qAmount, address = config.address) {
  const validators = await web3Adapter.validators()

  try {
    const rawAmount = web3Adapter.utils.toWei(qAmount)
    const callData = validators.methods.withdraw(rawAmount, address).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(validators._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Withdrawn ${qAmount} Q from validator stake. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Announce Withdrawal failed: ${err}`)  
  }
}

async function displayAccountData(address = config.address) {
  const validators = await web3Adapter.validators()

  const addressBalance = await web3Adapter.getBalance()
  const addressStake = await validators.methods.getValidatorStake(address).call()
  console.log('Q address:', address)
  console.log(`Balance: ${addressBalance / 10**18} Q - Validator Stake: ${addressStake / 10**18} Q`)

  const withdrawal = await validators.methods.withdrawals(address).call()
  if(!withdrawal.pending)
    console.log('No withdrawal is pending')
  else {
    const withdrawDate = new Date(withdrawal.time*1000)
    console.log(`Up to ${withdrawal.amount / 10**18} Q can be withdrawn after ${withdrawDate}`)
  }
  console.log()
}

async function displayShortList(highlightAddress = config.address) {
  const validators = await web3Adapter.validators()

  const shortlist = await validators.methods.getPositiveValidatorStake().call()
  const normalizedAddress = highlightAddress.toLowerCase()
  console.log('----------------------------------------------------------------------')
  shortlist.forEach((entry, i) => {
    const normalizedVal = entry.validator.toLowerCase()
    const higlight = normalizedAddress == normalizedVal ? '=>' : '  '
    console.log(`${higlight}${i+1}. ${entry.validator} - ${entry.amount / 10**18} Q`)
  });
  console.log('----------------------------------------------------------------------')
}

async function main() {
  const qAmount = '2'

  await displayAccountData()
  await commit(qAmount)
  await enterShortList()
  // await announceWithdrawal(qAmount)
  // await withdraw(qAmount)
  await displayAccountData()
  await displayShortList()
}

main()
