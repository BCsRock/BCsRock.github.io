var config = require('../config.json');
var Web3 = require('web3')
var Tx = require('ethereumjs-tx').Transaction;
var Common = require('ethereumjs-common').default;
var keyth=require('keythereum')

var keyobj=keyth.importFromFile(config.address, config.keystoreDirectory)
var privateKey=keyth.recover(config.password, keyobj) //this takes a few seconds to finish
console.log(privateKey.toString('hex'))

let registryABI = [{"inputs":[{"internalType":"address[]","name":"_maintainersList","type":"address[]"},{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"contains","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getContracts","outputs":[{"components":[{"internalType":"string","name":"key","type":"string"},{"internalType":"address","name":"addr","type":"address"}],"internalType":"structContractRegistry.Pair[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"keys","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"leaveMaintainers","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"mustGetAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"address","name":"_addr","type":"address"}],"name":"setAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"name":"setAddresses","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_maintainer","type":"address"}],"name":"setMaintainer","outputs":[],"stateMutability":"nonpayable","type":"function"}]
let addressOfRegistry = '0xc5bd57892163e9f76f657a53fe7cd971a1be9916'

// we are in the server side and metmask is not available
const provider = new Web3.providers.HttpProvider(
    config.rpc
);
web3 = new Web3(provider);

registryContract = new web3.eth.Contract(registryABI, addressOfRegistry)


let contractKeys = ['tokeneconomics.defaultAllocationProxy', 'tokeneconomics.rootNodeRewardProxy', 'tokeneconomics.validationRewardProxy']

async function allocate() {

  for(var i = 0; i < contractKeys.length;i++){

    await registryContract.methods.mustGetAddress(contractKeys[i]).call( (err, address) => {
      console.log('get address from registry err: ' + err)
      console.log(contractKeys[i] + ' allocation proxy Address: ' + address)

      let abi = [{"inputs":[{"internalType":"address","name":"contractRegistryAddress","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"string","name":"_parametersKey","type":"string"},{"internalType":"string","name":"_registryKey","type":"string"}],"name":"addBeneficiary","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"allocate","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_parametersKey","type":"string"},{"internalType":"string","name":"_registryKey","type":"string"}],"name":"removeBeneficiary","outputs":[],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]

      defAllocationContract = new web3.eth.Contract(abi, address)

      let myData = defAllocationContract.methods.allocate().encodeABI();
      const account1 = web3.eth.accounts.privateKeyToAccount(privateKey.toString('hex')).address;
      console.log('sender address: ' + account1);

      const customCommon = Common.forCustomChain(
        'mainnet',
        {
          name: 'my-network',
          networkId: 35443,
          chainId: 35443,
        },
        'petersburg',
      )

      let nonce = 0

      web3.eth.getTransactionCount(account1, (err, txCount) => {
        console.log('get nonce err: ' + err)
        console.log('nonce: ' + txCount)
        nonce = txCount 
      // Build the transaction
        const txObject = {
          from: account1,
          nonce:    web3.utils.toHex(txCount),
          to:       address,
          value:    web3.utils.toHex(web3.utils.toWei('0', 'ether')),
          gasLimit: web3.utils.toHex(2100000),
          gasPrice: web3.utils.toHex(web3.utils.toWei('1', 'gwei')),
          data: myData
        }
        // Sign the transaction
        
        const tx = new Tx(txObject, {common:customCommon});
        tx.sign(privateKey);

        const serializedTx = tx.serialize();
        const raw = '0x' + serializedTx.toString('hex');

        // Broadcast the transaction
        const transaction = web3.eth.sendSignedTransaction(raw, (err, tx) => {
            console.log('send tx err: ' + err)
            console.log('tx hash: ' + tx)
            console.log('allocate for ' + contractKeys[i] + ' invoked')
        })
      })
    })

    await new Promise(resolve => setTimeout(resolve, 30000));
  }
}

allocate()

