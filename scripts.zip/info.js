var config = require('../config.json');
var Web3 = require('web3')

let registryABI = [{"inputs":[{"internalType":"address[]","name":"_maintainersList","type":"address[]"},{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"contains","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getContracts","outputs":[{"components":[{"internalType":"string","name":"key","type":"string"},{"internalType":"address","name":"addr","type":"address"}],"internalType":"structContractRegistry.Pair[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"keys","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"leaveMaintainers","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"mustGetAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"address","name":"_addr","type":"address"}],"name":"setAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"name":"setAddresses","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_maintainer","type":"address"}],"name":"setMaintainer","outputs":[],"stateMutability":"nonpayable","type":"function"}]
let addressOfRegistry = '0xc5bd57892163e9f76f657a53fe7cd971a1be9916'

// we are in the server side and metmask is not available
const provider = new Web3.providers.HttpProvider(
    config.rpc
);
web3 = new Web3(provider);

registryContract = new web3.eth.Contract(registryABI, addressOfRegistry)

async function info() {
  validatorsKey = 'governance.validators'

  await (registryContract.methods.mustGetAddress(validatorsKey).call(async function (err, address) {
    console.log('get address from registry err: ' + err)
    console.log(validatorsKey + ' address: ' + address)

    let abi = [{"inputs":[{"internalType":"address","name":"_registry","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"announceWithdrawal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"commitCollateral","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"enterShortList","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getDelegatorsShare","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getInterestRate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getMaxTotalValidatorStakesLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getPositiveValidatorStake","outputs":[{"components":[{"internalType":"address","name":"validator","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"internalType":"struct Validators.ValidatorAmount[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getValidatorStake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getValidatorsList","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"makeSnapshot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_qsv","type":"uint256"}],"name":"setDelegatorsShare","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_qiv","type":"uint256"}],"name":"setInterestRate","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"validator","type":"address"}],"name":"validatorExist","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"payTo","type":"address"}],"name":"withdraw","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"withdrawals","outputs":[{"internalType":"bool","name":"pending","type":"bool"},{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function"}]

    validatorsContract = new web3.eth.Contract(abi, address)

    await validatorsContract.methods.getValidatorsList().call( async(err, addresses) => {
      console.log('validators list snapshot:')
      for (let i = 0; i < addresses.length; i++) {
        console.log(addresses[i])
      }
    });

    await validatorsContract.methods.getPositiveValidatorStake().call(async(err, addresses) => {
      console.log('validators list current state:')
      for (let i = 0; i < addresses.length; i++) {
        console.log(addresses[i][0] + ' '+ addresses[i][1])
      }
    })
  })) 

  await new Promise(resolve => setTimeout(resolve, 500));

  rootNodesContractKey = 'governance.rootNodes'

  await registryContract.methods.mustGetAddress(rootNodesContractKey).call(async (err, address) => {
    console.log('get address from registry err: ' + err)
    console.log(rootNodesContractKey + ' address: ' + address)

    let abi = [{"inputs":[{"internalType":"address","name":"_registry","type":"address"},{"internalType":"address[]","name":"rootsAddressesArray","type":"address[]"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"root","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"CommittedStake","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"root","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"WithdrawalAnnounced","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"root","type":"address"},{"indexed":false,"internalType":"address","name":"paidTo","type":"address"},{"indexed":false,"internalType":"uint256","name":"amount","type":"uint256"}],"name":"Withdrawn","type":"event"},{"inputs":[{"internalType":"address","name":"_rootAddress","type":"address"}],"name":"addRoot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"announceWithdrawal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"rootAddress","type":"address"},{"internalType":"address","name":"newRootAddress","type":"address"}],"name":"changeRoot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"toCheck","type":"address"}],"name":"checkMember","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"commitStake","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"rootAddress","type":"address"}],"name":"deleteRoot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"getCount","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getMembers","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"root","type":"address"}],"name":"getRootNodeStake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getStakes","outputs":[{"components":[{"internalType":"address","name":"root","type":"address"},{"internalType":"uint256","name":"value","type":"uint256"}],"internalType":"struct Roots.Stake[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"address payable","name":"payTo","type":"address"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"withdrawals","outputs":[{"internalType":"bool","name":"pending","type":"bool"},{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function"}]

    rootsContract = new web3.eth.Contract(abi, address)

    await rootsContract.methods.getMembers().call(async(err, addresses) => {
      console.log('root nodes current list:')
      for (let i = 0; i < addresses.length; i++) {
        console.log(addresses[i])
      }
    });
  }) 

  await new Promise(resolve => setTimeout(resolve, 500));

  await registryContract.methods.getContracts().call(async (err, addresses) => {
    console.log('system contract current list:')
    for (let i = 0; i < addresses.length; i++) {
      console.log(addresses[i][0] + ' '+ addresses[i][1])
    }
  }) 

  await new Promise(resolve => setTimeout(resolve, 500));
  constitionParamsKey = 'governance.constitution.parameters'

  await registryContract.methods.mustGetAddress(constitionParamsKey).call(async (err, address) => {
    console.log('get address from registry err: ' + err)
    console.log(constitionParamsKey + ' address: ' + address)

    let abi = [{"inputs":[],"name":"decimal","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getAddr","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getAddrKeys","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getBool","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBoolKeys","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getBytes32","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getBytes32Keys","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getDecimal","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getString","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getStringKeys","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getUint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getUintKeys","outputs":[{"internalType":"string[]","name":"","type":"string[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getVersionHash","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"removeAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"removeBool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"removeBytes32","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"removeString","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"removeUint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"address","name":"_val","type":"address"}],"name":"setAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"bool","name":"_val","type":"bool"}],"name":"setBool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"bytes32","name":"_val","type":"bytes32"}],"name":"setBytes32","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newDecimal","type":"uint256"}],"name":"setDecimal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"string","name":"_val","type":"string"}],"name":"setString","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"uint256","name":"_val","type":"uint256"}],"name":"setUint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"newHash","type":"string"}],"name":"setVersionHash","outputs":[],"stateMutability":"nonpayable","type":"function"}]

    paramsContract = new web3.eth.Contract(abi, address)

    await paramsContract.methods.getUintKeys().call(async(err, addresses) => {
      console.log(err)
  
      console.log('params uint list:')
      for (let i = 0; i < addresses.length; i++) {
        await paramsContract.methods.getUint(addresses[i]).call(async (err, value) => {
          console.log(addresses[i] + ' ' + value)
        })
      }
    });

    await new Promise(resolve => setTimeout(resolve, 8000));

    await paramsContract.methods.getStringKeys().call(async(err, addresses) => {
      console.log(err)
  
      console.log('params string list:')
      for (let i = 0; i < addresses.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 10));
        await paramsContract.methods.getString(addresses[i]).call(async (err, value) => {
          console.log(addresses[i] + ' ' + value)
        })
      }
    });

    await new Promise(resolve => setTimeout(resolve, 100));

    await paramsContract.methods.getBoolKeys().call(async(err, addresses) => {
      console.log(err)
  
      console.log('params bool list:')
      for (let i = 0; i < addresses.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 10));
        await paramsContract.methods.getBool(addresses[i]).call(async (err, value) => {
          console.log(addresses[i] + ' ' + value)
        })
      }
    });

    await new Promise(resolve => setTimeout(resolve, 100));

    await paramsContract.methods.getAddrKeys().call(async(err, addresses) => {
      console.log(err)
  
      console.log('params addr list:')
      for (let i = 0; i < addresses.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 10));
        await paramsContract.methods.getAddr(addresses[i]).call(async (err, value) => {
          console.log(addresses[i] + ' ' + value)
        })
      }
    });

    await new Promise(resolve => setTimeout(resolve, 100));

    await paramsContract.methods.getBytes32Keys().call(async(err, addresses) => {
      console.log(err)
  
      console.log('params bytes32 list:')
      for (let i = 0; i < addresses.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 10));
        await paramsContract.methods.getBytes32(addresses[i]).call(async (err, value) => {
          console.log(addresses[i] + ' ' + value)
        })
      }
    });
    
  }) 

  await new Promise(resolve => setTimeout(resolve, 11000));
  paramVotingAbi = [{"inputs":[{"internalType":"bytes32","name":"_constitutionHash","type":"bytes32"},{"internalType":"address","name":"_register","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_id","type":"uint256"},{"indexed":false,"internalType":"bytes32","name":"_constitutionHash","type":"bytes32"}],"name":"ProposalConsumed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_id","type":"uint256"}],"name":"ProposalCreated","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_id","type":"uint256"},{"indexed":false,"internalType":"enum ConstitutionVoting.VotingPosition","name":"_votingPosition","type":"uint8"},{"indexed":false,"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"UserVoted","type":"event"},{"inputs":[],"name":"constitutionHash","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"consume","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"getConstitutionHash","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"getStatus","outputs":[{"internalType":"enum ConstitutionVoting.ProposalStatus","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"getVetosPercentageNumber","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"getVotesTotal","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"hasRootVetoed","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"hasUserVoted","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"proposalCounter","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"proposals","outputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"classification","type":"uint8"},{"internalType":"string","name":"url","type":"string"},{"internalType":"bytes32","name":"constitutionHash","type":"bytes32"},{"internalType":"bool","name":"consumed","type":"bool"},{"components":[{"components":[{"internalType":"uint256","name":"startDate","type":"uint256"},{"internalType":"uint256","name":"endDate","type":"uint256"}],"internalType":"struct ConstitutionVoting.ProposalPeriod","name":"period","type":"tuple"},{"internalType":"uint256","name":"vetoEndDate","type":"uint256"},{"internalType":"uint256","name":"vetosCount","type":"uint256"},{"internalType":"uint256","name":"weightFor","type":"uint256"},{"internalType":"uint256","name":"weightAgainst","type":"uint256"},{"internalType":"uint256","name":"vetoThreshold","type":"uint256"}],"internalType":"struct ConstitutionVoting.VotingParams","name":"voting","type":"tuple"},{"internalType":"string","name":"parameterKey","type":"string"},{"internalType":"enum ConstitutionVoting.ParameterType","name":"parameterType","type":"uint8"},{"components":[{"internalType":"address","name":"addrValue","type":"address"},{"internalType":"bool","name":"boolValue","type":"bool"},{"internalType":"bytes32","name":"bytes32Value","type":"bytes32"},{"internalType":"string","name":"strValue","type":"string"},{"internalType":"uint256","name":"uintValue","type":"uint256"}],"internalType":"struct ConstitutionVoting.ParameterValue","name":"parameterValue","type":"tuple"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"}],"name":"proposeChange","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"},{"internalType":"string","name":"_paramKey","type":"string"},{"internalType":"address","name":"_paramValue","type":"address"}],"name":"proposeChangeAddr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"},{"internalType":"string","name":"_paramKey","type":"string"},{"internalType":"bool","name":"_paramValue","type":"bool"}],"name":"proposeChangeBool","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"},{"internalType":"string","name":"_paramKey","type":"string"},{"internalType":"bytes32","name":"_paramValue","type":"bytes32"}],"name":"proposeChangeBytes","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"},{"internalType":"string","name":"_paramKey","type":"string"},{"internalType":"string","name":"_paramValue","type":"string"}],"name":"proposeChangeStr","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"enum ConstitutionVoting.Classification","name":"_proposalType","type":"uint8"},{"internalType":"string","name":"_link","type":"string"},{"internalType":"bytes32","name":"_hashValue","type":"bytes32"},{"internalType":"string","name":"_paramKey","type":"string"},{"internalType":"uint32","name":"_paramValue","type":"uint32"}],"name":"proposeChangeUint","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"veto","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"voteAgainst","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_id","type":"uint256"}],"name":"voteFor","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]

  constitionParamsVotingKey = 'governance.constitution.parametersVoting'

  await registryContract.methods.mustGetAddress(constitionParamsVotingKey).call(async (err, address) => {
    console.log('get address from registry err: ' + err)
    console.log(constitionParamsVotingKey + ' address: ' + address)

    paramsVotingContract = new web3.eth.Contract(paramVotingAbi, address)

    await paramsVotingContract.methods.getStatus(0).call(async(err, addresses) => {
      console.log(err)
  
      console.log('proposals:')
      for (let i = 0; i < addresses.length; i++) {
        console.log(addresses[i])
        
      }
    });
  })

}

info()

