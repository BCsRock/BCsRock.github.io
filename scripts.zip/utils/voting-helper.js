const web3Adapter = require('./web3-adapter.js')

class VotingHelper {
  constructor(votingContract, hasQPBweight) {
    this.votingContract = votingContract
    this.hasQPBweight = hasQPBweight
  }

  async getProposals() {
    const proposalEvents = await this.votingContract.getPastEvents('ProposalCreated', { fromBlock: 0, toBlock: 'latest' })
    const proposalIds = proposalEvents.map(evt => evt.returnValues._id)
    
    const calls = proposalIds.map(id => this.getProposalDataById(id))
    return await Promise.all(calls)
  }

  async getProposalDataById(proposalId){
    const baseData = await this.votingContract.methods.proposals(proposalId).call()
    baseData.id = proposalId
    baseData.status = await this.getProposalStatus(proposalId)
    if(baseData.voteParams && baseData.voteParams.period) {
      baseData.endDate = baseData.voteParams.period.votingEndTime
    }
    return baseData
  }
    
  async getProposalStatus(proposalId) {
    const statusCode = await this.votingContract.methods.getStatus(proposalId).call()
    // const status = ProposalStatus(statusCode)
    switch (statusCode) {
      case '0': return 'NONE'
      case '1': return 'PENDING'
      case '2': return 'REJECTED'
      case '3': return 'ACCEPTED'
      case '4': return 'PASSED'
      case '5': return 'CONSUMED'
      default: return undefined
    }
  }
  
  async voteFor(proposalId, extendQPBLocking) {
    return await this.vote(true, proposalId, extendQPBLocking)
  }
  
  async voteAgainst(proposalId, extendQPBLocking) {
    return await this.vote(false, proposalId, extendQPBLocking)
  }

  prepareVotingMethod(voteFor, proposalId, extendQPBLocking) {
    if(this.hasQPBweight && voteFor) return this.votingContract.methods.voteFor(proposalId, extendQPBLocking)
    if(this.hasQPBweight && !voteFor) return this.votingContract.methods.voteAgainst(proposalId, extendQPBLocking)
    if(!this.hasQPBweight && voteFor) return this.votingContract.methods.voteFor(proposalId)
    if(!this.hasQPBweight && !voteFor) return this.votingContract.methods.voteAgainst(proposalId)
    throw new Error(`cannot prepare voting method for (${voteFor}, ${proposalId},${extendQPBLocking})`)
  }
  
  async vote(voteFor, proposalId, extendQPBLocking) {
    try {
      const votingMethod = this.prepareVotingMethod(voteFor, proposalId, extendQPBLocking)
      const callData = votingMethod.encodeABI()
      const nonce = await web3Adapter.getNonce()
      console.log('Sending transaction with nonce', nonce)
      const txObject = await web3Adapter.buildTransaction(this.votingContract._address, nonce, '0', callData)
      const receipt = await web3Adapter.submitTransaction(txObject)
  
      const forOrAgainst = voteFor ? 'FOR' : 'AGAINST'
      console.log(`Voted ${forOrAgainst} proposal ${proposalId}. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)
      return receipt
    } catch (err) {
      console.log(`Voting failed: ${err}`)  
    }
  }
  
  async execute(proposalId) {
    // TODO
  }
}



module.exports = VotingHelper