const config = require('../../config.json');
const Web3 = require('web3')
const Tx = require('ethereumjs-tx').Transaction;
const Common = require('ethereumjs-common').default;
const keyth = require('keythereum')

const keyobj=keyth.importFromFile(config.address, config.keystoreDirectory)
const privateKey=keyth.recover(config.password, keyobj) //this takes a few seconds to finish

const addressOfRegistry = '0xc5bd57892163e9f76f657a53fe7cd971a1be9916'
const registryABI = [{"inputs":[{"internalType":"address[]","name":"_maintainersList","type":"address[]"},{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"contains","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"getAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getContracts","outputs":[{"components":[{"internalType":"string","name":"key","type":"string"},{"internalType":"address","name":"addr","type":"address"}],"internalType":"structContractRegistry.Pair[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"keys","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"leaveMaintainers","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"}],"name":"mustGetAddress","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"_key","type":"string"},{"internalType":"address","name":"_addr","type":"address"}],"name":"setAddress","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string[]","name":"_keys","type":"string[]"},{"internalType":"address[]","name":"_addresses","type":"address[]"}],"name":"setAddresses","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_maintainer","type":"address"}],"name":"setMaintainer","outputs":[],"stateMutability":"nonpayable","type":"function"}]
const qPiggyBankABI = [{"inputs":[{"internalType":"address","name":"_registry","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"_holder","type":"address"},{"indexed":false,"internalType":"uint256","name":"_amount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_expiration","type":"uint256"}],"name":"AssetsLocked","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"_holder","type":"address"},{"indexed":false,"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"AssetsUnlocked","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"_holder","type":"address"},{"indexed":false,"internalType":"uint256","name":"_expectedRewardAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_actualRewardAmount","type":"uint256"}],"name":"RewardClaimed","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_newDepositAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_newBalance","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_latestClaim","type":"uint256"}],"name":"UserDeposited","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_withdrawnAmount","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_newBalance","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"_latestClaim","type":"uint256"}],"name":"UserWithdrawn","type":"event"},{"inputs":[{"internalType":"bool","name":"_unsatisfyableClaims","type":"bool"}],"name":"claim","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_unsatisfyableClaims","type":"bool"}],"name":"deposit","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_newExpiration","type":"uint256"}],"name":"extendExpiration","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_userAddress","type":"address"}],"name":"getUserBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"},{"internalType":"uint256","name":"_expiration","type":"uint256"}],"name":"lock","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"lockedAssets","outputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"expiration","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"}],"name":"unlock","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"usersData","outputs":[{"internalType":"uint256","name":"balance","type":"uint256"},{"internalType":"uint256","name":"latestClaim","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_amount","type":"uint256"},{"internalType":"bool","name":"_unsatisfyableClaims","type":"bool"}],"name":"withdraw","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}]
const validatorsABI = [{"inputs":[{"internalType":"address","name":"parametersAddress","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"announceWithdrawal","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"commitCollateral","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"enterShortList","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getDelegatorsShare","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getInterestRate","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getMaxTotalValidatorStakesLength","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getPositiveValidatorStake","outputs":[{"components":[{"internalType":"address","name":"validator","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"internalType":"structValidators.ValidatorAmount[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addr","type":"address"}],"name":"getValidatorStake","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getValidatorsList","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"makeSnapshot","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_qsv","type":"uint256"}],"name":"setDelegatorsShare","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_qiv","type":"uint256"}],"name":"setInterestRate","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"validator","type":"address"}],"name":"validatorExist","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"addresspayable","name":"payTo","type":"address"}],"name":"withdraw","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"withdrawals","outputs":[{"internalType":"bool","name":"pending","type":"bool"},{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint256","name":"amount","type":"uint256"}],"stateMutability":"view","type":"function"}]

const rootsMembershipVotingABI = [{"inputs":[{"internalType":"address","name":"_registryAddress","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"uint256","name":"_id","type":"uint256"},{"indexed":false,"internalType":"address","name":"_candidate","type":"address"},{"indexed":false,"internalType":"string","name":"_remark","type":"string"},{"indexed":false,"internalType":"address","name":"_replaceDest","type":"address"}],"name":"ProposalCreated","type":"event"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"approveAdditionalProposal","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"approveRemovalProposal","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"approveReplacementProposal","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"_constHash","type":"string"},{"internalType":"address","name":"_candidate","type":"address"},{"internalType":"string","name":"_remark","type":"string"},{"internalType":"address","name":"_replaceDest","type":"address"}],"name":"createProposal","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"getStatus","outputs":[{"internalType":"enum RootsVoting.ProposalStatus","name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"getVetosNumber","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"getVetosPercentageNumber","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"getVotesAgainst","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"getVotesFor","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"hasRootVetoed","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"proposals","outputs":[{"internalType":"address","name":"candidate","type":"address"},{"internalType":"string","name":"remark","type":"string"},{"internalType":"address","name":"replaceDest","type":"address"},{"internalType":"enum RootsVoting.ProposalType","name":"proposalType","type":"uint8"},{"internalType":"uint256","name":"weightFor","type":"uint256"},{"internalType":"uint256","name":"weightAgainst","type":"uint256"},{"internalType":"uint256","name":"votesCount","type":"uint256"},{"internalType":"uint256","name":"vetosCount","type":"uint256"},{"components":[{"components":[{"internalType":"uint256","name":"votingStartTime","type":"uint256"},{"internalType":"uint256","name":"votingEndTime","type":"uint256"}],"internalType":"struct RootsVoting.ProposalPeriod","name":"period","type":"tuple"},{"internalType":"uint256","name":"vetoEndTime","type":"uint256"},{"internalType":"uint256","name":"quorum","type":"uint256"},{"internalType":"uint256","name":"threshold","type":"uint256"},{"internalType":"uint256","name":"vetoThreshold","type":"uint256"}],"internalType":"struct RootsVoting.VotingParams","name":"voteParams","type":"tuple"},{"internalType":"bool","name":"consumed","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"veto","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"},{"internalType":"bool","name":"_isExpirationExtendable","type":"bool"}],"name":"voteAgainst","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"},{"internalType":"bool","name":"_isExpirationExtendable","type":"bool"}],"name":"voteFor","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"},{"internalType":"address","name":"","type":"address"}],"name":"votes","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_proposalId","type":"uint256"}],"name":"votingDuring","outputs":[{"internalType":"uint256","name":"from","type":"uint256"},{"internalType":"uint256","name":"to","type":"uint256"}],"stateMutability":"view","type":"function"}]

// we are in the server side and metmask is not available
const provider = new Web3.providers.HttpProvider(
    config.rpc
);
web3 = new Web3(provider);
// doesn't work. Seems we would need web3 1.2.7 at least for this to work for sendSignedTransaction
// see https://github.com/ethereum/web3.js/issues/3345
web3.eth.handleRevert = true

const network = config.networkId || 35443
const customCommon = Common.forCustomChain(
  'mainnet',
  {
    name: 'my-network',
    networkId: network,
    chainId: network,
  },
  'petersburg',
)

registryContract = new web3.eth.Contract(registryABI, addressOfRegistry)

async function getBalance(address) {
  addr = address || config.address
  let rawAmount = await web3.eth.getBalance(addr)
  return rawAmount
}

async function getTotalQInExistence() {
  const initialQ = 1e10 // 10 billion Q
  const blockSubsidy = 15 // 15 Q per Block
  const blockNumber = await web3.eth.getBlockNumber()
  return initialQ + blockNumber*blockSubsidy
}

async function getNonce(offset) {
  let nonce = await web3.eth.getTransactionCount(config.address)
  if(offset) nonce+=offset
  return nonce
}

async function buildTransaction(to, nonce, qAmount, data, gasLimit, gasPriceGwei) {
  limit = gasLimit || 2100000
  price = gasPriceGwei || '1'

  const txObject = {
    from: config.address,
    nonce,
    to,
    value:    web3.utils.toHex(web3.utils.toWei(qAmount, 'ether')),
    gasLimit: web3.utils.toHex(limit),
    gasPrice: web3.utils.toHex(web3.utils.toWei(price, 'gwei')),
    data
  }

  return txObject
}

async function submitTransaction(txObject) {
  const tx = new Tx(txObject, {common:customCommon});
  tx.sign(privateKey);

  const serializedTx = tx.serialize();
  const raw = '0x' + serializedTx.toString('hex');

  const receipt = await web3.eth.sendSignedTransaction(raw)
  .once('transactionHash', txHash => console.log('txHash', txHash))
  // .on('confirmation', (confNumber, _) => console.log('confNumber', confNumber))

  return receipt
}



function decodeEventArgs(eventName, log) {
  if(log.returnValues) {
    console.log('returnValues exist already:', log)   
  }

  const abiSection = this._jsonInterface.filter(e => e.type == 'event' && e.name === eventName)[0]
  if(!abiSection) {
    console.log(`An event with name '${eventName}' is not defined for this contract`)
  }

  const returnValues = web3.eth.abi.decodeLog(abiSection.inputs, log.data)
  return returnValues
}

async function getContractInstance(registryKey, abi) {
  const instanceAddr = await registryContract.methods.mustGetAddress(registryKey).call()
  const instance = new web3.eth.Contract(abi, instanceAddr)
  instance.handleRevert = true // doesn't work. Maybe need more recent geth version
  instance.decodeEventArgs = decodeEventArgs // kind of hacky
  return instance
}

const utils = {
  zeroAddress: '0x0000000000000000000000000000000000000000',
  toWei: web3.utils.toWei,
  fromWei: web3.utils.fromWei,
  toBN: web3.utils.toBN,
  fromFixedPoint: function(ticks, asPercentage) {
    const resolution = 1e27
    if(asPercentage) return ticks/resolution * 100
    return ticks/resolution
  },
  dateToBlockTime: function(date) {
    return Math.floor(date.getTime() / 1000)
  }
}

module.exports = {
  utils,
  getNonce,
  getBalance,
  getTotalQInExistence,
  buildTransaction,
  submitTransaction,
  registryContract,
  qPiggyBank: () => getContractInstance('tokeneconomics.qPiggyBank', qPiggyBankABI),
  validators: () => getContractInstance('governance.validators', validatorsABI),
  rootsMembershipVoting: () => getContractInstance('governance.rootNodes.membershipVoting', rootsMembershipVotingABI),
}
