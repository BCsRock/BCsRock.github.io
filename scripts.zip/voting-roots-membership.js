const web3Adapter = require('./utils/web3-adapter.js')
const config = require('../config.json')
const VotingHelper = require('./utils/voting-helper.js')

async function createAddProposal(offchainLink, addressToAdd) {
  return await createProposal(addressToAdd, offchainLink, web3Adapter.utils.zeroAddress)
}

async function createRemoveProposal(offchainLink, addressToRemove) {
  return await createProposal(web3Adapter.utils.zeroAddress, offchainLink, addressToRemove)
}


async function createProposal(addressToAdd, offchainLink, addressToRemove) {
  const rmv = await web3Adapter.rootsMembershipVoting()

  try {
    const dummyHash = '0815'
    const callData = rmv.methods.createProposal(dummyHash, addressToAdd, offchainLink, addressToRemove).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(rmv._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)

    const evtData = rmv.decodeEventArgs('ProposalCreated', receipt.logs[0])
    const createdId = evtData._id
    console.log(`Created root node membership proposal '${createdId}'. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Root node membership proposal failed: ${err}`)  
  }
}

async function vote(voteFor, proposalId, extendQPBLocking = true) {
  const rmv = await web3Adapter.rootsMembershipVoting()
  const vh = new VotingHelper(rmv, true)

  if(proposalId == undefined) {
    const proposals = (await vh.getProposals()).reverse()
    if(proposals.length > 0) proposalId = proposals[0].id // newest proposal
  }

  await vh.vote(voteFor, proposalId, extendQPBLocking)
}

function toPercentage(numerator, denominator, precision=2) {
  if(denominator == 0) return 0 // mathematically not correct but useful here

  const tmpPrecision=precision+2
  const rounded = Math.round(numerator * 10**tmpPrecision / denominator)
  return rounded / 10**precision
}

async function displayProposals() {
  const rmv = await web3Adapter.rootsMembershipVoting()

  const vh = new VotingHelper(rmv, true)
  const proposals = (await vh.getProposals()).reverse()
  const qInExistence = await web3Adapter.getTotalQInExistence()

  console.log(`ID\tSTATUS\tENDS\t\t\t\tOFFCHAIN-LINK`)
  proposals.forEach(p => {
    const endDate = new Date(p.endDate * 1000)
    console.log(`${p.id}\t${p.status}\t${endDate.toISOString()}\t${p.remark}`)
    const indent = '\t->'
    switch(p.proposalType) {
      case '1' /*add*/: 
        console.log(`${indent} Proposal to add '${p.candidate}' to the root node panel`);
        break;
      case '2' /*remove*/:
        console.log(`${indent} Proposal to remove '${p.replaceDest}' from the root node panel`);
        break;
      case '3' /*replace*/: 
        console.log(`${indent} Proposal to replace ${p.candidate} by ${p.replaceDest} in the root node panel`);
        break;
    }

    const qFor = p.weightFor / 10**18
    const qAgainst = p.weightAgainst / 10**18
    const qTotal = qFor + qAgainst
    const maj = toPercentage(qFor, qTotal)
    const rmaj = web3Adapter.utils.fromFixedPoint(p.voteParams.threshold, true)
    const qrm = toPercentage(qTotal, qInExistence, 4)
    const rqrm = web3Adapter.utils.fromFixedPoint(p.voteParams.quorum, true)
    console.log(`${indent} FOR: ${qFor} --- AGAINST: ${qAgainst} --- Total:${qTotal} --- VETOS: ${p.vetosCount}`)
    console.log(`${indent} MAJ:${maj}%. Required majority of ${rmaj}% ${maj >= rmaj ? 'reached' : 'not reached'}`)
    console.log(`${indent} QRM:${qrm}%. Required quorum of ${rqrm}% ${qrm >= rqrm ? 'reached' : 'not reached'}`)
  })
}

async function main() {
  const me = config.address
  const voteFor = true
  // const proposalId = 2
  await createAddProposal(`www.q.org/addRoot-${me.substr(2, 4)}`, me)
  await createRemoveProposal('www.q.org/removeRoot-532c', '0x532c69263800e1f1Cdb72acaE555A85864146986')
  await vote(voteFor) 
  // await vote(voteFor, proposalId) 
  await displayProposals()
}

main()