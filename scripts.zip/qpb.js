const web3Adapter = require('./utils/web3-adapter.js')
const config = require('../config.json')

async function deposit(qAmount, abandonClaims=false) {
  const qpb = await web3Adapter.qPiggyBank()

  try {
    const callData = qpb.methods.deposit(abandonClaims).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(qpb._address, nonce, qAmount, callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Added ${qAmount} Q to piggy bank account. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Piggy bank deposit failed: ${err}`)  
  }
}

async function claim(abandonClaims=false) {
  const qpb = await web3Adapter.qPiggyBank()
  
  try {
    const abandonClaims = false
    const callData = qpb.methods.claim(abandonClaims).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const qAmount = '0'
    const txObject = await web3Adapter.buildTransaction(qpb._address, nonce, qAmount, callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Claimed reward for Q piggy bank account. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Piggy bank claim failed: ${err}`)  
  }
}

async function withdraw(qAmount, abandonClaims=false) {
  const qpb = await web3Adapter.qPiggyBank()

  try {
    const rawAmount = web3Adapter.utils.toWei(qAmount)
    const callData = qpb.methods.withdraw(rawAmount, abandonClaims).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(qpb._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Withdrawn ${qAmount} Q from piggy bank account. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Piggy bank withdrawal failed: ${err}`)  
  }
}

async function lock(qAmount, lockUntilDate) {
  const qpb = await web3Adapter.qPiggyBank()
  if(!lockUntilDate) lockUntilDate = new Date()

  try {
    const expiration = web3Adapter.utils.dateToBlockTime(lockUntilDate)
    const rawAmount = web3Adapter.utils.toWei(qAmount)
    const callData = qpb.methods.lock(rawAmount, expiration).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(qpb._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Locked ${qAmount} Q from piggy bank account. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Locking failed: ${err}`)  
  }
}

async function unlock(qAmount) {
  const qpb = await web3Adapter.qPiggyBank()

  try {
    const rawAmount = web3Adapter.utils.toWei(qAmount)
    const callData = qpb.methods.unlock(rawAmount).encodeABI()
    const nonce = await web3Adapter.getNonce()
    console.log('Sending transaction with nonce', nonce)
    const txObject = await web3Adapter.buildTransaction(qpb._address, nonce, '0', callData)
    const receipt = await web3Adapter.submitTransaction(txObject)
    console.log(`Unlocked ${qAmount} Q from piggy bank account. Block Number: ${receipt.blockNumber}; Gas Used: ${receipt.gasUsed}`)  
  } catch (err) {
    console.log(`Unlocking failed: ${err}`)  
  }
}

async function displayAccountData(address = config.address) {
  const qpb = await web3Adapter.qPiggyBank()

  const addressBalance = await web3Adapter.getBalance(address)
  const qpbAccount = await qpb.methods.usersData(address).call()
  const lockedAssets = await qpb.methods.lockedAssets(address).call()
  // const delegatedStakes = await qpb.methods.delegatedStakes(address).call()
  console.log('Q address:', address)
  console.log(`Balance: ${addressBalance / 10**18} Q - QPB Balance: ${qpbAccount.balance / 10**18} Q`)

  // console.log(`delegatedStakes`, delegatedStakes)

  if(lockedAssets.amount == 0) {
    console.log('No Q is locked for voting')
  } else {
    const lockedUntilDate = new Date(lockedAssets.expiration*1000)
    console.log(`${lockedAssets.amount / 10**18} Q is locked for voting until ${lockedUntilDate}`)
    console.log(`${(qpbAccount.balance - lockedAssets.amount) / 10**18} Q available for immediate withdraw.`) 
  }

  if(qpbAccount.latestClaim == 0) {
    console.log('Never claimed reward')
  } else {
    // const claimDate = new Date(qpbAccount.latestClaim*1000) // if we switch to seconds
    console.log(`Claimed reward at block height ${qpbAccount.latestClaim}`)
  }
  console.log()
}


async function main() {
  const qAmount = '2.5'
  const lockQAmount = '1'

  await displayAccountData()
  await deposit(qAmount)
  await lock(lockQAmount)
  await unlock(lockQAmount)
  await claim()
  await withdraw(qAmount)  
  await displayAccountData()
}

main()
